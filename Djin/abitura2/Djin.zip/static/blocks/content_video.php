﻿<br><br><br>
<div style="margin:18px auto;">
<font face="italic" size="+3" color="black" > <center> <b><?php echo $Lang['video_of_the_department']; ?></b></center> </font>
    
<!-- Insert to your webpage where you want to display the carousel -->
<div id="amazingcarousel-container-2">
    <div id="amazingcarousel-2" style="display:none;position:relative;width:100%;max-width:750px;margin:0px auto 0px;">
        <div class="amazingcarousel-list-container">
            <ul class="amazingcarousel-list">
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="https://www.youtube.com/embed/tNhqiMrhfTI" title="Трейлер о кафедре"  class="html5lightbox"><img src="../static/images/img_video/tNhqiMrhfTI.jpg"  alt="Трейлер о кафедре" /></a></div>
<div class="amazingcarousel-title"><b><?php echo $Lang["home_of_the_department"]; ?></b></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="https://www.youtube.com/embed/Z-Df087HPQU" title="Информационный ролик о специальностях кафедры"  class="html5lightbox"><img src="../static/images/img_video/Z-Df087HPQU.jpg"  alt="Информационный ролик о специальностях кафедры" /></a></div>
<div class="amazingcarousel-title"><b><?php echo $Lang["video"]; ?></b></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="https://www.youtube.com/embed/aSMah6ij7Zo" title="Церемония награждения победителей первого Заочного конкурса по информатике и математике!"  class="html5lightbox"><img src="../static/images/img_video/aSMah6ij7Zo.jpg"  alt="Церемония награждения победителей первого Заочного конкурса по информатике и математике!" /></a></div>
<div class="amazingcarousel-title"><b><?php echo $Lang["video1"]; ?></b></div>                    </div>
                </li>
            </ul>
            <div class="amazingcarousel-prev"></div>
            <div class="amazingcarousel-next"></div>
        </div>
        <div class="amazingcarousel-nav"></div>
    </div>
</div>
<!-- End of body section HTML codes -->
</div>
<br><br><br>