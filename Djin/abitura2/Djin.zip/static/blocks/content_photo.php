﻿<br><br>
<div>
<br>
<p> <font face="Arial" size="+3" color="black" > <center> <b><?php echo $Lang['entertainment']; ?></b></center> </font></p> 
   <section class="regular slider">
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/0.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/N.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/T.jpg">
    </div>
    <div class="blockimgs">
     <img id="img1" src="../static/images/img_photo/quest/Y.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/X.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/P.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/I.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/II.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/III.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/N.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/F.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/IIII.jpg">
    </div> 
	<div class="blockimgs">
     <img id="img1" src="../static/images/img_photo/quest/Z.jpg">
    </div>
	<div class="blockimgs">
     <img id="img1" src="../static/images/img_photo/quest/14.jpg">
    </div>
	</div> 
  </section>
  
 <pre>
 
 
 
 
 </pre>
 
 <p> <font face="Arial" size="+3" color="black" > <center> <b> <?php echo $Lang['conference']; ?></b></center> </font></p> 
  <section class="regular slider">
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/1.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/2.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/3.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/4.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/5.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/6.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/7.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/8.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/9.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/10.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/11.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/12.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/13.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/conference/14.jpg">
    </div>
  </section>
 
  <pre>
 
 
 
 
 </pre>
 
<p> <font face="Arial" size="+3" color="black" > <center> <b><?php echo $Lang['activity']; ?></b></center> </font></p>  
  <section class="regular slider">
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/1.jpg">
    </div>
    <div  class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/2.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/3.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/4.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/5.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/6.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/7.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/8.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/9.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/10.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/11.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/12.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/13.jpg">
    </div>
	<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/speech/14.jpg">
    </div>
  </section>
  
  <pre>
 
 
 
 
 </pre>

 <p> <font face="Arial" size="+3" color="black" > <center> <b><?php echo $Lang['teachers']; ?></b></center> </font></p> 
  <section class="regular slider">
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Breslavskiy.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t1']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d1']; ?></div>   
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/PhotoYura.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t2']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d2']; ?></div> 
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Plakciy.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t3']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d3']; ?></div>
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Uspensky.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t4']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d4']; ?></div>  
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Korytko.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t5']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d5']; ?></div>
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Tatarinova.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t6']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d6']; ?></div> 
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Nekrasova.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t7']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d7']; ?></div>
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Grizun.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t8']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d8']; ?></div>
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Hazko.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t9']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d8']; ?></div> 
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Kozluk.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t10']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d10']; ?></div> 
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/Metelev.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t11']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d11']; ?></div> 
    </div>
<div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/teachers/pashenko.jpg">
	  <div class="amazingcarousel-title"><b><?php echo $Lang['t13']; ?></b></div>
<div class="amazingcarousel-description"><?php echo $Lang['d10']; ?></pre></div> 
    </div>
	 
  </section>
</div>
<br><br><br>