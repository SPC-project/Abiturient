﻿<head>

</head>

<body>
<center>
<img width="620" src="../static/images/images/projects.png"></img>
</center>
<p align="center" style="font-size:27px;"><?php echo $Lang['other']; ?></p>
<p style="font-size:20px; text-indent:40px;	text-align:justify;margin-left:5px;margin-right:15px;">
<?php echo $Lang['other_description']; ?>
</p>
<br><br><br>
<center>

<p align="center" style="font-size:22px;">
<?php echo $Lang['department_site']; ?>
</p>
<img src="../static/images/images/screen1.png"></img>
</center>
<p style="font-size:20px; text-indent:40px;	text-align:justify;margin-left:5px;margin-right:15px;line-height: 1.2;">
<?php echo $Lang['department_site_description']; ?>
</p>
<br><br><br>
<p align="center" style="font-size:22px;">
<?php echo $Lang['VK']; ?>
</p>
<center>
<img src="../static/images/images/screen2.png"></img>
</center>
<p style="font-size:20px; text-indent:40px;	text-align:justify;margin-left:5px;margin-right:15px;line-height: 1.2;">
<?php echo $Lang['VK_description']; ?>
</p>
<br><br><br>
<p align="center" style="font-size:22px;">
<?php echo $Lang['students_record_book']; ?>
</p>
<center>
<img width="650" src="../static/images/images/zach.jpg"></img>
</center>
<p style="font-size:20px; text-indent:40px;	text-align:justify;margin-left:5px;margin-right:15px;line-height: 1.2;">
<?php echo $Lang['students_record_book_description']; ?>
<br><br><br>
<p align="center" style="font-size:22px;">
<?php echo $Lang['course_project']; ?>
</p>
<center>
<img width="650" src="../static/images/images/kursach.png"></img>
</center>
<p style="font-size:20px; text-indent:40px;	text-align:justify;margin-left:5px;margin-right:15px;line-height: 1.2;">
<?php echo $Lang['course_project_description']; ?>
</p> 
 <br><br><br>
<p align="center" style="font-size:26px;">
<?php echo $Lang['not_all']; ?>
</p>
<center>
<img width="650" src="../static/images/images/tbc.png"></img>
</center>
<br>
</body>