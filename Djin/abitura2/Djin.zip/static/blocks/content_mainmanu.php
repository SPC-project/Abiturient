<div>
<br>
<center>
<p>
		<a href="../templates/calculator.php"><button class="btn btn-3 btn-3e size icon-arrow-right"><?php echo $Lang['calculator']; ?></button></a>
		<a href="../templates/files.php"><button class="btn btn-3 btn-3e size icon-arrow-right"><?php echo $Lang['list_of_files']; ?></button></a><br>
		<a href="../templates/calculator.php" alt="<?php echo $Lang['calculator']; ?>" title="<?php echo $Lang['calculator']; ?>"><button class="btn btn-1 btn-1a"></button></a><nobr>
		<a href="../templates/files.php" alt="<?php echo $Lang['list_of_files']; ?>" title="<?php echo $Lang['list_of_files']; ?>"><button class="btn1 btn-1 btn-1a"></button></a>
		</p>
		</center>
</div>
<div>
<br>
<center>
<p>
		<a href="../templates/photos_department.php"><button class="btn btn-3 btn-3e size icon-arrow-right"><?php echo $Lang['department_of_Pictures']; ?></button></a>
		<a href="../templates/videos_department.php"><button class="btn btn-3 btn-3e size icon-arrow-right"><?php echo $Lang['video_of_the_department']; ?></button></a>
		<a href="../templates/projects.php"><button class="btn btn-3 btn-3e size icon-arrow-right"><?php echo $Lang['projects']; ?></button></a><br>
		<a href="../templates/photos_department.php" alt="<?php echo $Lang['department_of_Pictures']; ?>" title="<?php echo $Lang['department_of_Pictures']; ?>"><button class="btn4 btn-1 btn-1a"></button></a><nobr>
		<a href="../templates/videos_department.php" alt="<?php echo $Lang['video_of_the_department']; ?>" title="<?php echo $Lang['video_of_the_department']; ?>"><button class="btn5 btn-1 btn-1a"></button></a><nobr>
		<a href="../templates/projects.php" alt="<?php echo $Lang['projects']; ?>" title="<?php echo $Lang['projects']; ?>"><button class="btn6 btn-1 btn-1a"></button></a><nobr>
</p>
</center>
</div>
<br>
<br>

