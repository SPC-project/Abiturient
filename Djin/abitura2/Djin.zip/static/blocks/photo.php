﻿<br><br>
<div>
<br>
<p> <font face="Arial" size="+3" color="black" > <center> <b><?php echo $Lang['entertainment']; ?></b></center> </font></p> 
   <section class="regular slider">
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/0.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/N.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/T.jpg">
    </div>
    <div class="blockimgs">
     <img id="img1" src="../static/images/img_photo/quest/Y.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/X.jpg">
    </div>
    <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/P.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/I.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/II.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/III.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/N.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/F.jpg">
    </div>
	 <div class="blockimgs">
      <img id="img1" src="../static/images/img_photo/quest/IIII.jpg">
    </div> 
	<div class="blockimgs">
     <img id="img1" src="../static/images/img_photo/quest/Z.jpg">
    </div>
	<div class="blockimgs">
     <img id="img1" src="../static/images/img_photo/quest/14.jpg">
    </div>
	</div> 
  </section>
  </div>
<br><br><br>