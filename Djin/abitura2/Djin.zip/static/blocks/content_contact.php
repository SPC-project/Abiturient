<br>
<br>
<br>
		<h1 style="font-style: italic;" align="center"><?php echo $Lang['contact_us']; ?></h1>
		<p style="text-align: center; font-size: 16pt"><?php echo $Lang['us']; ?></p>
		<br>
		<p style="text-align: center;"><a href="mailto:spukhpi@gmail.com" class="button"/><?php echo $Lang['email']; ?></a></p>
	
	<br>
	
		<h1><?php echo $Lang['find']; ?></h1>
<table>
  <tr>
    <td align="center"><p class="adress" style="font-size: 16pt"><?php echo $Lang['address']; ?>
				<h1><?php echo $Lang['communication']; ?> :)</h1>
	<div class="share-new">
		<a class="icon-vk" href="https://vk.com/official_spu" title="<?php echo $Lang['vk'];?>" target="_blank"></a>
		<a class="icon-mail" href="mailto:spukhpi@gmail" title="<?php echo $Lang['email']; ?>" > <!-- target="_blank" --> </a>
		<a  class="icon-e" href="http://web.kpi.kharkov.ua/spu/"  title="<?php echo $Lang['ethernet']; ?>" target="_blank"></a>
	</div>
		</p>
	</td>
		<div>
			<a href="https://goo.gl/GpZgGO" target="_blank">
			<img align="right" id="mapimg" src="../static/images/images/map2.jpg"></a>
			<br><br><br>
		</div>		
  </tr>
</table>
<br>
<br>
