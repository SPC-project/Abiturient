﻿<br>
<script type="text/javascript" src="//vk.com/js/api/openapi.js?136"></script>

<!-- VK Widget -->
<div id="vk_community_messages"></div>
<script type="text/javascript">
VK.Widgets.CommunityMessages("vk_community_messages", 73612507, {disableExpandChatSound: "1",tooltipButtonText: "Есть вопрос?"});
</script>
<?php echo $Lang["footer"]; ?>
